public class Tester {

    /**
     * <b>Question:</b>
     * <p>
     * Write a RECURSIVE method, {@code bsum}, that returns {@code true}
     * <strong>if and only if</strong>, starting from the provided index
     * {@code start}, if there is some combo of integers in {@code nums} that
     * sums to the provided {@code targetAmt}. Each number can be used only once.
     * <p>
     * The method should return {@code false} if this is not possible. No loops
     * are needed.
     * <p><b>Some examples:</b>
     * <ul>
     * <li>bsum(1, [2, 4, 8], 8) returns true</li>
     * <li>bsum(1, [2, 4, 8], 2) returns false</li>
     * <li>bsum(0, [2, 4, 8], 8) returns true</li>
     * <li>bsum(1, [9], 0) returns true</li>
     * <li>bsum(1, [], 0) returns true</li>
     * <li>bsum(1, [], 1) returns false</li>
     * </ul>
     */
    public static boolean bsum(int start, int[] nums, int targetAmt) {




    }
}
